// Lista naszych graczy i ich pseudonimów
const PLAYER_BY_STEAM = {
    "76561198009437428": "Dziadek",
    "76561198021612193": "Wujek",
    "76561198863079353": "Ojciec",
    "76561198019301588": "Synek",
    "76561198043824587": "Matka",
    "76561198080571359": "Kowal",
    "76561199075504972": "Gruby",
    "76561198035378205": "Telemans"
};

// Główna funkcja pobierająca dane
function extractMatchData() {
    const matchData = [];
    
    // Pobierz ID meczu z URL
    const matchId = window.location.pathname.split('/').pop();
    console.log('Match ID:', matchId);
    
    // Pobierz datę meczu
    const dateElement = document.querySelector('#match-info-inner .glyphicon-time ~ span');
    const matchDate = dateElement ? dateElement.textContent.trim() : '';
    console.log('Match Date:', matchDate);
    
    // Pobierz mapę
    let mapName = '';
    const mapElement = document.querySelector('.info img[alt*="cs_"], .info img[title*="cs_"]');
    if (mapElement) {
        mapName = mapElement.getAttribute('title') || mapElement.getAttribute('alt') || '';
    }
    if (!mapName) {
        const mapText = document.querySelector('.info:contains("cs_")');
        if (mapText) {
            const text = mapText.textContent.trim();
            const match = text.match(/cs_[a-z0-9_]+/);
            mapName = match ? match[0] : '';
        }
    }
    console.log('Map:', mapName);
    
    // Pobierz wynik meczu
    const teamScores = document.querySelectorAll('.team-score-number');
    let team1Score = teamScores[0] ? teamScores[0].textContent.trim() : '0';
    let team2Score = teamScores[1] ? teamScores[1].textContent.trim() : '0';
    const matchScore = `${team1Score}:${team2Score}`;
    
    // Określ wynik (WIN/LOSS/TIE)
    let matchResult = 'TIE';
    if (parseInt(team1Score) > parseInt(team2Score)) matchResult = 'LOSS';
    else if (parseInt(team2Score) > parseInt(team1Score)) matchResult = 'WIN';
    console.log('Score:', matchScore, 'Result:', matchResult);
    
    // Znajdź wszystkie TBODY w scoreboard - każde TBODY to osobna drużyna
    const tbodyElements = document.querySelectorAll('#match-scoreboard tbody');
    console.log('Found TBODY elements:', tbodyElements.length);
    
    // Najpierw ZBIERZ WSZYSTKICH GRACZY z obu drużyn
    const team1Players = [];
    const team2Players = [];
    
    tbodyElements.forEach((tbody, tbodyIndex) => {
        const teamPlayers = tbodyIndex === 0 ? team1Players : team2Players;
        const rows = tbody.querySelectorAll('tr');
        
        rows.forEach(row => {
            if (row.querySelector('td[rowspan]')) return;
            
            const playerLink = row.querySelector('a[href*="/player/"]');
            if (!playerLink) return;
            
            const href = playerLink.getAttribute('href');
            const steamId = href.split('/').pop();
            const playerName = playerLink.querySelector('span')?.textContent.trim() || '';
            
            teamPlayers.push({
                steamId,
                name: playerName
            });
        });
    });
    
    console.log('Team 1 players:', team1Players.map(p => p.name).join(', '));
    console.log('Team 2 players:', team2Players.map(p => p.name).join(', '));
    
    // Teraz przetwórz każdego naszego gracza
    tbodyElements.forEach((tbody, tbodyIndex) => {
        // Określ drużynę na podstawie kolejności TBODY
        // Pierwsze TBODY = Team 1 = T
        // Drugie TBODY = Team 2 = CT
        const teamSide = tbodyIndex === 0 ? 'T' : 'CT';
        const teamNumber = tbodyIndex === 0 ? 'Team 1' : 'Team 2';
        const currentTeamPlayers = tbodyIndex === 0 ? team1Players : team2Players;
        const opposingTeamPlayers = tbodyIndex === 0 ? team2Players : team1Players;
        
        console.log(`\n=== Processing ${teamNumber} (${teamSide}) ===`);
        
        const rows = tbody.querySelectorAll('tr');
        
        rows.forEach(row => {
            if (row.querySelector('td[rowspan]')) return;
            
            const playerLink = row.querySelector('a[href*="/player/"]');
            if (!playerLink) return;
            
            const href = playerLink.getAttribute('href');
            const steamId = href.split('/').pop();
            const playerName = playerLink.querySelector('span')?.textContent.trim() || '';
            
            // Sprawdź czy gracz jest w naszej liście
            const isOurPlayer = Object.keys(PLAYER_BY_STEAM).includes(steamId);
            
            if (!isOurPlayer) return; // Pomijamy graczy spoza listy
            
            console.log(`  ✓ ${teamNumber} (${teamSide}): ${playerName} - ${steamId}`);
            
            // Pobierz wszystkie dane statystyczne z komórek
            const cells = row.querySelectorAll('td');
            
            // Mapowanie kolumn
            let kills = '0', deaths = '0', assists = '0', plusMinus = '0';
            let adr = '0', hsPercent = '0', kast = '0%', rating = '0';
            let ef = '0', fa = '0', ebt = '0s', ud = '0';
            let fk = '0', fd = '0';
            let tradeKills = '0', tradeDeaths = '0';
            let oneV5 = '0', oneV4 = '0', oneV3 = '0', oneV2 = '0', oneV1 = '0';
            let fiveK = '0', fourK = '0', threeK = '0';
            
            cells.forEach((cell, idx) => {
                const text = cell.textContent.trim();
                
                if (idx === 5) kills = text;
                if (idx === 6) deaths = text;
                if (idx === 7) assists = text;
                if (idx === 8) plusMinus = text;
                if (idx === 10 && text && !isNaN(parseFloat(text))) adr = text;
                if (idx === 11 && text.includes('%')) hsPercent = text.replace('%', '');
                if (idx === 12 && text.includes('%')) kast = text;
                
                if (idx === 13) {
                    const ratingSpan = cell.querySelector('span');
                    if (ratingSpan) rating = ratingSpan.textContent.trim();
                    else if (text && !isNaN(parseFloat(text))) rating = text;
                }
                
                if (idx === 14) ef = text;
                if (idx === 15) fa = text;
                if (idx === 16) ebt = text;
                if (idx === 17) ud = text;
                if (idx === 20) fk = text;
                if (idx === 21) fd = text;
                if (idx === 28) tradeKills = text;
                if (idx === 29) tradeDeaths = text;
                if (idx === 36) oneV5 = text;
                if (idx === 37) oneV4 = text;
                if (idx === 38) oneV3 = text;
                if (idx === 39) oneV2 = text;
                if (idx === 40) oneV1 = text;
                if (idx === 42) fiveK = text;
                if (idx === 43) fourK = text;
                if (idx === 44) threeK = text;
            });
            
            // Znajomi w drużynie - liczba naszych graczy w tej samej drużynie
            const friendsInTeam = currentTeamPlayers.filter(p => 
                Object.keys(PLAYER_BY_STEAM).includes(p.steamId)
            ).length;
            
            // Skład NASZEJ drużyny - używamy nazw z PLAYER_BY_STEAM dla naszych graczy
            const teamRoster = currentTeamPlayers.map(p => {
                const customName = PLAYER_BY_STEAM[p.steamId];
                return customName || p.name;
            }).join(', ');
            
            // Skład DRUŻYNY PRZECIWNEJ - oryginalne nicki
            const opposingRoster = opposingTeamPlayers.map(p => p.name).join(', ');
            
            console.log(`     👥 Nasz skład: ${teamRoster}`);
            console.log(`     👤 Przeciwnicy: ${opposingRoster}`);
            console.log(`     👥 Znajomi w drużynie: ${friendsInTeam}`);
            
            // Przygotuj obiekt z danymi
            const playerObject = {
                "ID meczu": parseInt(matchId) || 0,
                "Steam ID": parseInt(steamId) || 0,
                "Gracz": PLAYER_BY_STEAM[steamId] || playerName,
                "Data": matchDate,
                "Mapa": mapName,
                "Wynik": matchScore,
                "Result": matchResult,
                "Kills": parseInt(kills) || 0,
                "Deaths": parseInt(deaths) || 0,
                "Assists": parseInt(assists) || 0,
                "Plus/Minus": parseInt(plusMinus) || 0,
                "HS%": parseInt(hsPercent) || 0,
                "ADR": Math.round(parseFloat(adr)) || 0,
                "KAST": kast.includes('%') ? kast : kast + '%',
                "EF": parseInt(ef) || 0,
                "FA": parseInt(fa) || 0,
                "EBT": ebt,
                "UD": parseInt(ud) || 0,
                "FK": parseInt(fk) || 0,
                "FD": parseInt(fd) || 0,
                "Trade Kills": parseInt(tradeKills) || 0,
                "Trade Deaths": parseInt(tradeDeaths) || 0,
                "1v5": parseInt(oneV5) || 0,
                "1v4": parseInt(oneV4) || 0,
                "1v3": parseInt(oneV3) || 0,
                "1v2": parseInt(oneV2) || 0,
                "1v1": parseInt(oneV1) || 0,
                "5K": parseInt(fiveK) || 0,
                "4K": parseInt(fourK) || 0,
                "3K": parseInt(threeK) || 0,
                "Rating": rating.replace('.', ','),
                "Drużyna": teamSide,
                "Znajomi w drużynie": friendsInTeam,
                "Skład": teamRoster,
                "Drużyna przeciwna": opposingRoster
            };
            
            matchData.push(playerObject);
        });
    });
    
    console.log(`\n✅ Znaleziono ${matchData.length} naszych graczy w meczu`);
    return matchData;
}

// Funkcja do kopiowania JSON do schowka
function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
}

// Dodaj przycisk na stronie
function addExportButton() {
    if (document.getElementById('csstats-export-btn')) return;
    
    const header = document.querySelector('.main-header');
    if (header) {
        const exportBtn = document.createElement('button');
        exportBtn.id = 'csstats-export-btn';
        exportBtn.textContent = '📋 Eksportuj JSON (nasi gracze)';
        exportBtn.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            background: #2c3e50;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s;
            border: 1px solid #34495e;
        `;
        exportBtn.onmouseover = () => {
            exportBtn.style.background = '#34495e';
            exportBtn.style.transform = 'translateY(-2px)';
            exportBtn.style.boxShadow = '0 6px 8px rgba(0,0,0,0.15)';
        };
        exportBtn.onmouseout = () => {
            exportBtn.style.background = '#2c3e50';
            exportBtn.style.transform = 'translateY(0)';
            exportBtn.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
        };
        exportBtn.onclick = () => {
            try {
                const data = extractMatchData();
                if (data.length === 0) {
                    alert('❌ Nie znaleziono żadnych naszych graczy w tym meczu!\n\nSprawdź konsolę (F12) aby zobaczyć listę znalezionych graczy.');
                    return;
                }
                const jsonString = JSON.stringify(data, null, 4);
                copyToClipboard(jsonString);
                alert(`✅ Pobrano dane dla ${data.length} graczy!\nJSON skopiowany do schowka.`);
                
                console.log('=== WYEXSPORTOWANE DANE ===');
                console.log(JSON.stringify(data, null, 2));
                console.log('============================');
            } catch (error) {
                alert('❌ Błąd: ' + error.message);
                console.error(error);
            }
        };
        document.body.appendChild(exportBtn);
        console.log('✅ Przycisk eksportu dodany');
    }
}

// Automatyczne uruchomienie
window.addEventListener('load', () => {
    setTimeout(addExportButton, 500);
    console.log('✅ CSStats Exporter załadowany');
});

// Debug
window.extractCSStatsMatch = extractMatchData;
window.debugPlayers = () => {
    console.log('Nasi gracze (SteamID):', Object.keys(PLAYER_BY_STEAM));
    extractMatchData();
};